# DevPath — IT Roadmap & Study Planner

Prototype web app dành cho sinh viên IT tại Việt Nam.

## Chức năng hiện có
- Dashboard tổng quan và thống kê mẫu.
- Roadmap tương tác cho Software Engineering, AI, Cybersecurity, Data Science và Computer Networks.
- Xem chi tiết từng milestone và thêm milestone thành task.
- Thêm task, phân loại task, đánh dấu hoàn thành.
- Lưu task và chế độ sáng/tối trong `localStorage`.
- Resource Hub với liên kết đến tài liệu học tập.
- Responsive layout cho màn hình lớn và điện thoại.

## Chạy thử
Mở `index.html` bằng Chrome hoặc Edge. Cần Internet để tải Tailwind CSS từ CDN.

## Đưa lên GitHub Pages
1. Tạo repository mới trên GitHub, ví dụ `devpath-study-planner`, chọn **Public**.
2. Tải lên `index.html`, thư mục `data/`, `README.md` và `.nojekyll`.
3. Vào **Settings → Pages**.
4. Trong phần **Build and deployment**, chọn **Deploy from a branch**.
5. Chọn branch `main`, folder `/(root)`, rồi nhấn **Save**.
6. Chờ GitHub Pages build và mở URL được hiển thị trong phần Pages.

## Cấu trúc
```text
devpath-web/
├── index.html
├── data/
│   └── roadmaps.json
├── README.md
├── .nojekyll
└── .gitignore
```

## Giới hạn hiện tại
Đây là prototype frontend, chưa có backend, đăng nhập, đồng bộ dữ liệu giữa thiết bị hoặc database. Task được lưu cục bộ trên trình duyệt, nên giáo viên mở link trên máy khác sẽ không nhìn thấy task cá nhân của bạn. Các số liệu trên Dashboard hiện là dữ liệu demo.

## Hướng phát triển tiếp theo
1. Tách HTML thành React components và chuyển sang TypeScript.
2. Đọc roadmap từ `data/roadmaps.json` thay vì hard-code.
3. Dùng Supabase/PostgreSQL cho tài khoản, roadmap cá nhân, task và nhật ký học.
4. Thêm kiểm thử, xử lý lỗi, accessibility và README có ảnh chụp màn hình.
5. Chỉ đưa API keys không nhạy cảm ra frontend; secrets phải nằm ở môi trường server.
